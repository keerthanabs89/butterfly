# AgriPulse

## Overview

AgriPulse is a web-based agricultural platform that provides farmers and agricultural professionals with real-time commodity price data, weather forecasts, and AI-powered agricultural assistance. The application serves as a comprehensive dashboard for agricultural decision-making by aggregating essential data from government APIs and weather services while offering intelligent recommendations through Google's Gemini AI.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Single Page Application**: Uses vanilla HTML, CSS, and JavaScript for a lightweight, fast-loading interface
- **Responsive Design**: Mobile-first approach with CSS Grid and Flexbox for cross-device compatibility
- **Component-Based UI**: Modular CSS structure with reusable components for consistent styling
- **Real-time Updates**: Client-side JavaScript handles API interactions and dynamic content updates

### Backend Architecture
- **Node.js with Express**: RESTful API server providing three main endpoints for prices, weather, and AI chat
- **Stateless Design**: No session management or persistent user data storage
- **Environment-based Configuration**: Uses environment variables for API keys and port configuration
- **Error Handling**: Comprehensive try-catch blocks with appropriate HTTP status codes

### Data Flow Architecture
- **API Gateway Pattern**: Express server acts as a gateway, proxying requests to external services
- **Data Aggregation**: Combines multiple data sources (government commodity prices, weather data, AI responses)
- **Client-Side Rendering**: All data processing and UI updates happen in the browser

### AI Integration
- **Google Gemini Integration**: Uses Gemini 1.5 Flash model for agricultural advisory and chat functionality
- **Context-Aware Responses**: AI can provide insights based on current market prices and weather conditions
- **Streaming Support**: Configured for real-time AI response generation

## External Dependencies

### Government Data APIs
- **India Data Portal**: Commodity price data from api.data.gov.in
  - Provides real-time agricultural commodity prices across Indian markets
  - Rate-limited public API with 100-record pagination

### Weather Services
- **Open-Meteo API**: Free weather forecasting service
  - 7-day temperature and precipitation forecasts
  - Geolocation-based weather data (default: Delhi coordinates)
  - No authentication required

### AI Services
- **Google Generative AI**: Gemini 1.5 Flash model for conversational AI
  - Requires GEMINI_API_KEY environment variable
  - Used for agricultural advice and query responses

### Frontend Libraries
- **Font Awesome**: Icon library for enhanced UI elements
- **Google Fonts**: Inter font family for consistent typography

### Backend Dependencies
- **Express 5.x**: Web framework for API routing and middleware
- **Axios**: HTTP client for external API requests
- **CORS**: Cross-origin resource sharing middleware
- **@google/generative-ai**: Official Google AI SDK for Gemini integration